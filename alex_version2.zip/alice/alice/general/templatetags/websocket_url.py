from django import template
from django.conf import settings

register = template.Library()

@register.simple_tag
def websocket_url():
    if settings.WEBSOCKET_URL:
        return settings.WEBSOCKET_URL
    return ""