import logging
import os
import json
import requests

from django.conf import settings
from celery import shared_task
from channels.layers import get_channel_layer
from django.utils.timezone import now
from django.core.mail import send_mail
from asgiref.sync import async_to_sync
from .models import Alert, Notification

@shared_task
def send_notification_task(message):
    channel_layer = get_channel_layer()
    group_name = "user-notifications"
    event = {
        'type': 'send_notification',
        'text': message
    }
    async_to_sync(channel_layer.group_send)(group_name, event)

@shared_task
def send_notification_to_users_task(user_ids, title, message, alert_id):
    channel_layer = get_channel_layer()
    for user_id in user_ids:
        group_name = f"user_{user_id}"
        event = {
            'type': 'send_notification',
            'text': message,
            'title': title,
            'alert_id': alert_id
        }
        async_to_sync(channel_layer.group_send)(
            group_name,
            event
        )

@shared_task
def create_notifications_task(user_ids, alert_id):
    #alert = Alert.objects.get(id=alert_id)
    notifications = [
        Notification(user_id=user_id, alert_id=alert_id, dismissed=False, sent_at=now())
        for user_id in user_ids
    ]
    Notification.objects.bulk_create(notifications)

@shared_task
def send_notification_email(subject, message, recipient_list):
    """Celery task to send an email notification."""
    send_mail(
        subject,
        message,
        "no-reply@yourdomain.com",  # Change this to your sender email
        recipient_list,
        fail_silently=False,
    )

@shared_task
def send_notification_teams(subject, message):
    webhook_url = settings.ALICE_NOTIFICATIONS_TEAMS_WEBHOOK
    logging.info(f"Teams url: {webhook_url}")

    # example of usage in UNCHAINED
    #def send_outgoing_teams_webhook(card_title_text, card_content_text, card_button_1_text_title=None,
    #                                card_button_1_url=None):
    #send_outgoing_teams_webhook("Daily Data Import Task(s) Failed", f"Error executing details: {str(e)}",
    #                            "Open TIE Unchained", "http://tie.cnvrm.com/")
    #send_outgoing_teams_webhook("Starting Daily Monitoring Task",
    #                            f"Monitors are running sequentially, highest priority first.",
    #                            "Open Monitoring Dashboard", "http://tie.cnvrm.com/monitoring/dashboard/")

    json_payload = json.dumps({
        "type": "message",
        "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive",
            "contentUrl": None,
            "content": {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.2",
                "body": [{
                    "type": "TextBlock",
                    "text": subject,
                    "weight": "Bolder",
                    "size": "Large"
                }, {
                    "type": "TextBlock",
                    "text": message,
                    "size": "Medium",
                    "wrap": True
                }],
                "actions": [{
                    "type": "Action.OpenUrl",
                    "title": "Go to Alert",
                    "url": "https://google.com"
                }]
            }
        }]
    })
    r = requests.post(webhook_url, data=json_payload, headers={'Content-Type': 'application/json'})
    return r.status_code

