from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.conf import settings
from django.db.models.signals import post_save, post_migrate
from django.dispatch import receiver
from .models import Notification
from django.utils.timezone import now
from .models import Alert, Service

from .tasks import send_notification_task
from .tasks import send_notification_to_users_task, create_notifications_task, send_notification_email, send_notification_teams
import logging

logger = logging.getLogger(__name__)

@receiver(post_migrate)
def create_default_service(sender, **kwargs):
    if not Service.objects.exists():
        Service.objects.create(name="General", description="This is the default Service for system based Notifications.")

@receiver(post_save, sender=Alert)
def send_alert_notification(sender, instance, created, **kwargs):
    if created and instance.send_notifications:
        user_ids = list(instance.service.subscriptions.values_list("user_id", flat=True))
        #create_notifications_task.delay(user_ids, instance.id)
        notifications = [
            Notification(user_id=user_id, alert_id=instance.id, dismissed=False, sent_at=now())
            for user_id in user_ids
        ]
        Notification.objects.bulk_create(notifications)

        send_notification_to_users_task.delay(user_ids, instance.title, instance.message, instance.id)

        email_list = instance.email_list
        subject = f"{instance.service.name} Alert: {instance.title}"
        message = f"{instance.message}"
        if email_list and len(email_list) > 0:
            send_notification_email.delay(subject, message, email_list)
        if instance.send_teams_tie_notification:
            send_notification_teams.delay(subject, message)
