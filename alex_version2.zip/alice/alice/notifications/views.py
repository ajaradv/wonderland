import logging
from django.http import HttpResponse
from django.contrib import messages
from django.views.decorators.http import require_http_methods
from django.views.decorators.http import require_POST, require_GET
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.shortcuts import get_object_or_404

from .models import Service
from .models import Subscription
from .models import Notification
from .models import Alert


""" Notifications """
@login_required
def home(request):
    context = {"notifications": Notification.objects.select_related().filter(user=request.user.pk).order_by('-sent_at')}
    return render(request, "notifications/index.html", context)

@login_required
@require_GET
def fetch_dismissed_notifications(request):
    context = {"notifications": Notification.objects.select_related().filter(user=request.user.pk, dismissed=True).order_by('-sent_at')}
    return render(request, "notifications/partials/notification_table_list.html", context)

@login_required
@require_POST
def dismiss_notification(request, pk):
    notification = get_object_or_404(Notification, id=pk)
    notification.dismissed = True
    notification.save()
    response = HttpResponse(status=204)
    response["HX-Trigger"] = "dismiss-notification"
    return response

@login_required
@require_GET
def fetch_unread_notifications(request):
    notifications = Notification.objects.select_related().filter(user=request.user, dismissed=False)
    context = {'notifications': notifications}
    return render(request, "notifications/partials/notifications_alert_list.html", context)

""" Alerts """
def alerts(request):
    context = {"alerts": Alert.objects.select_related().all()}
    return render(request, "notifications/alerts.html", context)

@login_required
@require_POST
def toggle_alert_acknowledged(request, pk):
    alert = get_object_or_404(Alert, id=pk)
    alert.toggle_acknowledged()
    alert.save()
    if alert.acknowledged:
        messages.success(request, f"Alert Acknowledged")
    else:
        messages.warning(request, f"Help is on its way!")
    return render(request, "notifications/partials/toast.html")

""" Services """
def services(request):
    subscribed_services = list(map(lambda x: x.service.id , Subscription.objects.select_related().filter(user=request.user.pk)))
    context = {"services": Service.objects.all(),
               "subscriptions": subscribed_services
               }
    return render(request, "notifications/services.html", context)

@login_required
@require_POST
def subscribe_service(request, pk):
    service = get_object_or_404(Service, id=pk)
    subscription = Subscription(user=request.user, service=service)
    subscription.save()
    messages.success(request, f"Subscribed to {service.name}.")
    context = {"service": service}
    return render(request, "notifications/partials/services_row_subscribed.html", context)

@login_required
@require_POST
def delete_subscription(request, pk):
    service = get_object_or_404(Service, id=pk)
    subscription = Subscription.objects.filter(user=request.user, service=service)
    subscription.delete()
    messages.warning(request, f"Unsubscribed from {service.name}.")
    context = {"service": service}
    return render(request, "notifications/partials/services_row_unsubscribed.html", context)