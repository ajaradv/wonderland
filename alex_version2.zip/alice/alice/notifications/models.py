from django.db import models
from alice.users.models import User
from django.contrib.postgres.fields import ArrayField
from django.utils.translation import gettext_lazy as _

class Service(models.Model):
    name = models.CharField(max_length=30)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add = True)

    def __str__(self):
        return self.name


class Alert(models.Model):
    class PriorityType(models.TextChoices):
        HIGH = "H", _("High")
        MEDIUM = "M", _("Medium")
        LOW = "L", _("Low")

    title = models.CharField(max_length=30)
    message = models.TextField()
    url = models.URLField(default="https://alice.cnvrm.com/notifications/alerts/")
    acknowledged = models.BooleanField(default=False)
    send_notifications = models.BooleanField(default=True)
    priority = models.CharField(max_length=1, choices=PriorityType, default=PriorityType.MEDIUM)
    email_list = ArrayField(models.EmailField(), blank=True, default=list)
    send_teams_tie_notification = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add = True)
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="alerts")

    def __str__(self):
        return f"{self.title}: {self.message} ({self.url})"

    def toggle_acknowledged(self):
        self.acknowledged = False if self.acknowledged else True


class Notification(models.Model):
    dismissed = models.BooleanField(default=False)
    sent_at = models.DateTimeField(auto_now_add = True)
    alert = models.ForeignKey(Alert, on_delete=models.CASCADE, related_name="notifications")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")

    class Meta:
        unique_together = ("user", "alert")

class Subscription(models.Model):
    subscribed_at = models.DateTimeField(auto_now_add = True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="subscriptions")
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name="subscriptions")

    class Meta:
        unique_together = ("user", "service")
