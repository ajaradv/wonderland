from django.urls import path

from . import views

app_name = "notifications"

urlpatterns = [
    path("", views.home, name="notifications_home"),
    path("dismiss-notification/<int:pk>", views.dismiss_notification, name="dismiss-notification"),
    path("fetch-notifications", views.fetch_unread_notifications, name="fetch_notifications"),
    path("services", views.services, name="notifications_services"),
    path("subscribe-service/<int:pk>", views.subscribe_service, name="subscribe-service"),
    path("delete-subscription/<int:pk>", views.delete_subscription, name="delete-subscription"),
    path("alerts", views.alerts, name="notifications_alerts"),
    path("toggle-alert-acknowledged/<int:pk>", views.toggle_alert_acknowledged, name="toggle-alert-acknowledged")
]
