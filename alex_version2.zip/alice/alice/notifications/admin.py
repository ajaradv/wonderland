from django.contrib import admin
from unfold.admin import ModelAdmin
from .models import Service
from .models import Alert
from .models import Notification
from .models import Subscription

# Register your models here.

@admin.register(Service)
class ServiceAdmin(ModelAdmin):
    pass

@admin.register(Alert)
class AlertAdmin(ModelAdmin):
    pass

@admin.register(Notification)
class NotificationAdmin(ModelAdmin):
    pass

@admin.register(Subscription)
class SubscriptionAdmin(ModelAdmin):
    pass