import "../css/project.css";
import { themeChange } from "theme-change";

/* Project specific Javascript goes here. */
themeChange();
