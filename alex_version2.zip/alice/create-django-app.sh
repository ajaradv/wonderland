#!/bin/bash

# Check if the required parameters are provided
if [ -z "$1" ]; then
    echo "Usage: $0 <subdirectory>"
    exit 1
fi

# Assign parameters
SUBDIR=$1
DJANGO_COMMAND="startapp"
PROJECT_DIR="alice"
TEMPLATE_DIR="new_app_template"
NEW_DIR="$PROJECT_DIR/$SUBDIR"

# Set the project root dynamically (assumes script is in the project root or a subdirectory)
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || echo "$PWD")
cd "$PROJECT_ROOT" || exit

# Ensure the subdirectory exists
if [ ! -d "$NEW_DIR" ]; then
    echo "Subdirectory '$NEW_DIR' not found. Creating it..."
    mkdir -p "$NEW_DIR"
fi

CMD="django-admin $DJANGO_COMMAND $SUBDIR $NEW_DIR --template=$TEMPLATE_DIR"

# Execute the Django command in the project root
echo "Executing: $CMD"
$CMD
