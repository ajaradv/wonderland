from django.urls import path, re_path

from config.websocket import (EchoConsumer, NotificationConsumer, UserNotificationConsumer,
                              websocket_application)

websocket_routes = [
    path("", websocket_application),
    path("ws/echo/", EchoConsumer.as_asgi()),
    path("ws/notifications/", NotificationConsumer.as_asgi()),
    re_path("ws/notifications/user/$", UserNotificationConsumer.as_asgi()),
]
