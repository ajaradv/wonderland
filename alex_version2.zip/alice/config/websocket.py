import logging
import json

from asgiref.sync import async_to_sync
from channels.consumer import AsyncConsumer
from channels.generic.websocket import WebsocketConsumer
from channels.generic.websocket import AsyncWebsocketConsumer
from django.template.loader import get_template

logger = logging.getLogger(__name__)


class NotificationConsumer(WebsocketConsumer):
    """ Syncronous consumer """

    def connect(self):
        self.user = self.scope['user']
        if not self.user.is_authenticated:
            self.close()
            return
        self.GROUP_NAME = "user-notifications"
        async_to_sync(self.channel_layer.group_add)(
            self.GROUP_NAME, self.channel_name
        )
        self.accept()

    def disconnect(self, close_code):
        if self.user.is_authenticated:
            async_to_sync(self.channel_layer.group_discard)(
                self.GROUP_NAME, self.channel_name
            )

    def send_notification(self, event):
        html = get_template("/app/alice/templates/partials/notifications.html").render(
            context={'message': f"{event['text']}"}
        )
        self.send(text_data=html)

    def user_joined(self, event):
        logger.info(
            f"websocket transmission initiated for user join {event['text']}")
        html = get_template("/app/alice/templates/partials/notifications.html").render(
            context={'message': f"{event['text']} has joined!"}
        )
        self.send(text_data=html)

class UserNotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        """Connect the user to their WebSocket notification group."""
        self.user = self.scope["user"]
        if self.user.is_authenticated:
            self.group_name = f"user_{self.user.id}"
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, close_code):
        """Disconnect the user from the WebSocket group."""
        if self.user.is_authenticated:
            await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def send_notification(self, event):
        """Send notification message to the user."""
        html = get_template("/app/alice/templates/partials/notifications.html").render(
            context={'message': f"{event['text']}",
                     'title': f"{event['title']}",
                     }
        )
        await self.send(text_data=html)

class EchoConsumer(AsyncConsumer):
    """ Asyncrounous consumer """

    async def websocket_connect(self, event):
        await self.send(
            {
                "type": "websocket.accept",
            },
        )

    async def websocket_receive(self, event):
        await self.send(
            {
                "type": "websocket.send",
                "text": event["text"],
            },
        )


async def websocket_application(scope, receive, send):
    while True:
        event = await receive()

        if event["type"] == "websocket.connect":
            await send({"type": "websocket.accept"})

        if event["type"] == "websocket.disconnect":
            break

        if event["type"] == "websocket.receive":
            if event["text"] == "ping":
                await send({"type": "websocket.send", "text": "pong!"})
